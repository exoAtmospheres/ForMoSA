<p align="left"><img src="docs/source/ForMoSA.png" alt="ForMoSA" width="250"/></p>


Refer to our [ReadTheDocs](https://formosa.readthedocs.io/en/latest/index.html) page for installation instructions, demo and documentation details.


[![Documentation Status](https://readthedocs.org/projects/formosa/badge/?version=latest)](https://formosa.readthedocs.io/en/latest/?badge=latest)
[![PyPI version](https://badge.fury.io/py/formosa.svg)](https://badge.fury.io/py/formosa)
[![PyPI downloads](https://img.shields.io/pypi/dm/formosa.svg)](https://pypistats.org/packages/formosa)
[![License](https://img.shields.io/badge/License-BSD_2--Clause-orange.svg)](https://opensource.org/licenses/BSD-2-Clause)

***

This package is currently under testing process. 

**Soon available for the comunity, stay tunned!**


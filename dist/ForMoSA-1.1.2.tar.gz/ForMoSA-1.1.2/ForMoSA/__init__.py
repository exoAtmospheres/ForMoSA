import os

__version__ = "1.1.2"

__all__ = ['adapt', 'nested_sampling','plotting']